package batailleespagnole;

/**
 * Enumération des familles des cartes
 *
 * @author Line POUVARET
 */
public enum TypeFamille {

    Bâton,
    Or,
    Epée,
    Coupe;

}
